import SwiftUI
import WebKit

struct OscarWebView: UIViewRepresentable {
    @ObservedObject var browser: BrowserState

    func makeUIView(context: Context) -> WKWebView { browser.webView }
    func updateUIView(_ webView: WKWebView, context: Context) {}
}
