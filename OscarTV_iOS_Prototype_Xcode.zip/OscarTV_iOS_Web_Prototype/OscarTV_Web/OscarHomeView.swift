import SwiftUI
import WebKit

// This is an independent WEBSITE WRAPPER, not an Android APK conversion.
// It loads the publicly accessible OscarTV website at https://oscartv.app/.
struct OscarHomeView: View {
    @StateObject private var browser = BrowserState()
    @State private var showingShare = false

    var body: some View {
        VStack(spacing: 0) {
            HStack(spacing: 9) {
                Image(systemName: "play.rectangle.fill")
                    .foregroundStyle(.red)
                Text("OscarTV")
                    .font(.system(size: 19, weight: .bold))
                Spacer()
                Text("نسخة ويب")
                    .font(.system(size: 11, weight: .medium))
                    .foregroundStyle(.secondary)
            }
            .padding(.horizontal, 16)
            .frame(height: 51)
            .background(.regularMaterial)

            ZStack {
                OscarWebView(browser: browser)
                    .background(Color.black)
                if let error = browser.lastError {
                    VStack(spacing: 12) {
                        Image(systemName: "wifi.exclamationmark")
                            .font(.largeTitle)
                        Text("تعذّر فتح الصفحة")
                            .font(.headline)
                        Text(error)
                            .font(.footnote)
                            .multilineTextAlignment(.center)
                        Button("حاول مجددًا") { browser.reload() }
                            .buttonStyle(.borderedProminent)
                    }
                    .padding(28)
                    .frame(maxWidth: .infinity, maxHeight: .infinity)
                    .background(Color(uiColor: .systemBackground))
                }
            }

            if browser.isLoading {
                ProgressView(value: browser.progress)
                    .progressViewStyle(.linear)
                    .tint(.red)
            }

            HStack(spacing: 0) {
                tool("arrow.backward", title: "رجوع", enabled: browser.canGoBack) {
                    browser.goBack()
                }
                tool("arrow.forward", title: "التالي", enabled: browser.canGoForward) {
                    browser.goForward()
                }
                tool("house", title: "الرئيسية") { browser.goHome() }
                tool("arrow.clockwise", title: "تحديث") { browser.reload() }
                tool("square.and.arrow.up", title: "مشاركة") { showingShare = true }
            }
            .padding(.vertical, 8)
            .background(.regularMaterial)
        }
        .background(Color(uiColor: .systemBackground))
        .sheet(isPresented: $showingShare) {
            ShareView(items: [browser.webView.url ?? BrowserState.homeURL])
                .presentationDetents([.medium])
        }
    }

    private func tool(_ icon: String, title: String, enabled: Bool = true, action: @escaping () -> Void) -> some View {
        Button(action: action) {
            VStack(spacing: 4) {
                Image(systemName: icon).font(.system(size: 18, weight: .medium))
                Text(title).font(.system(size: 10))
            }
            .frame(maxWidth: .infinity)
            .frame(height: 42)
        }
        .disabled(!enabled)
        .accessibilityLabel(title)
    }
}

private struct ShareView: UIViewControllerRepresentable {
    let items: [Any]
    func makeUIViewController(context: Context) -> UIActivityViewController {
        UIActivityViewController(activityItems: items, applicationActivities: nil)
    }
    func updateUIViewController(_ controller: UIActivityViewController, context: Context) {}
}
