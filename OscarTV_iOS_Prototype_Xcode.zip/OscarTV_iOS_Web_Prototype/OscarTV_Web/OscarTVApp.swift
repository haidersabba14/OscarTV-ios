import SwiftUI

@main
struct OscarTVApp: App {
    var body: some Scene {
        WindowGroup {
            OscarHomeView()
                .tint(Color(red: 0.94, green: 0.17, blue: 0.18))
        }
    }
}
